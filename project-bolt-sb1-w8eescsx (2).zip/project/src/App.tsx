import React from 'react';
import { Flame, Copy, ExternalLink } from 'lucide-react';

function App() {
  const contractAddress = "0x7Ef2e0048f5bAeDe046f6BF797943daF4ED8CB47"; // Example contract address

  const copyAddress = () => {
    navigator.clipboard.writeText(contractAddress);
    alert("Contract address copied!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-900 to-black text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center text-center">
          <div className="mb-8 relative">
            <div className="w-48 h-48 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
              <Flame className="w-24 h-24 text-red-500" />
            </div>
            <div className="absolute -bottom-2 right-0 bg-red-500 rounded-full p-2">
              <Flame className="w-8 h-8 text-white animate-bounce" />
            </div>
          </div>

          <h1 className="text-5xl font-bold mb-4">Angry Pepe Coin</h1>
          <p className="text-xl mb-8 text-green-400">🔥 The Angriest Meme Coin in Crypto 🔥</p>

          <div className="bg-gray-800 rounded-lg p-6 max-w-xl w-full mb-8">
            <h2 className="text-lg mb-2">Contract Address:</h2>
            <div className="flex items-center justify-between bg-gray-700 rounded p-3">
              <code className="text-green-400">{contractAddress}</code>
              <button 
                onClick={copyAddress}
                className="ml-2 p-2 hover:bg-gray-600 rounded transition-colors"
              >
                <Copy className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3 max-w-4xl w-full">
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-2">Total Supply</h3>
              <p className="text-green-400">1,000,000,000,000</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-2">Holders</h3>
              <p className="text-green-400">12,345</p>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-2">Price</h3>
              <p className="text-green-400">$0.0000001</p>
            </div>
          </div>

          <a 
            href="#" 
            className="mt-8 inline-flex items-center bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-full transition-colors"
          >
            Trade Now <ExternalLink className="ml-2 w-5 h-5" />
          </a>
        </div>
      </div>
    </div>
  );
}

export default App;